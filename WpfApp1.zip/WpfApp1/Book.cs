﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace WpfApp1
{
    // 1. Tạo bảng Books để lưu thông tin sách theo mô tả bài toán
    [Table("Books")]
    public class Book
    {
        [Key]
        [StringLength(20)]
        public string MaSach { get; set; }

        [Required]
        [StringLength(150)]
        public string TenSach { get; set; }

        [Required]
        [StringLength(100)]
        public string TacGia { get; set; }

        public int NamXuatBan { get; set; }

        // Kiểu dữ liệu decimal(18,2) theo đúng bảng mô tả cấu trúc đề bài
        [Column(TypeName = "decimal")]
        public decimal DonGia { get; set; }
    }

    // 2. Xây dựng lớp DbContext để kết nối ứng dụng WPF với SQL Server bằng Entity Framework
    public class LibraryDbContext : DbContext
    {
        // Khởi tạo chuỗi kết nối linh hoạt (Quét cả SQL gốc và SQLEXPRESS, tự động tạo database nếu chưa có)
        public LibraryDbContext() : base("Data Source=.\\SQLEXPRESS;Initial Catalog=LibraryManagementDB;Integrated Security=True;Connection Timeout=8")
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<LibraryDbContext>());
        }

        public DbSet<Book> Books { get; set; }
    }
}