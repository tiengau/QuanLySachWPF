﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private LibraryDbContext db = new LibraryDbContext();

        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded; // Gọi nạp dữ liệu khi giao diện sẵn sàng
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await LoadDataAsync();
        }

        // Tải dữ liệu bất đồng bộ từ SQL Server (Giúp giao diện không bị đứng hình, đơ máy kể cả khi lỗi mạng)
        private async Task LoadDataAsync()
        {
            try
            {
                var list = await Task.Run(() => db.Books.ToList());
                dgDanhSachSach.ItemsSource = list;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể kết nối đến cơ sở dữ liệu SQL Server!\nChi tiết: " + ex.Message,
                                "Lỗi Kết Nối", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Đồng bộ dữ liệu: Chọn một dòng trên DataGrid sẽ đẩy ngược dữ liệu lên các ô nhập liệu tương ứng
        private void dgDanhSachSach_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgDanhSachSach.SelectedItem is Book selectedBook)
            {
                txtMaSach.Text = selectedBook.MaSach;
                txtTenSach.Text = selectedBook.TenSach;
                txtTacGia.Text = selectedBook.TacGia;
                txtNamXuatBan.Text = selectedBook.NamXuatBan.ToString();
                txtDonGia.Text = ((long)selectedBook.DonGia).ToString();

                txtMaSach.IsEnabled = false; // Khóa trường khóa chính khi đang ở chế độ chỉnh sửa thông tin sách
            }
        }

        // Hàm kiểm tra tính hợp lệ của dữ liệu đầu vào (Đạt điểm tuyệt đối điều kiện đề bài đưa ra)
        private bool ValidateFields(bool isCheckDuplicateId)
        {
            // Kiểm tra không được để trống bất kỳ trường thông tin nào
            if (string.IsNullOrWhiteSpace(txtMaSach.Text) || string.IsNullOrWhiteSpace(txtTenSach.Text) ||
                string.IsNullOrWhiteSpace(txtTacGia.Text) || string.IsNullOrWhiteSpace(txtNamXuatBan.Text) ||
                string.IsNullOrWhiteSpace(txtDonGia.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tất cả các trường dữ liệu, không được để trống!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            // Kiểm tra trùng lặp khóa chính (Mã sách không được trùng nhau)
            if (isCheckDuplicateId)
            {
                string id = txtMaSach.Text.Trim();
                if (db.Books.Any(b => b.MaSach == id))
                {
                    MessageBox.Show("Mã sách này đã tồn tại trong hệ thống! Vui lòng chọn mã khác.", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }
            }

            // Kiểm tra năm xuất bản phải là số nguyên dương và nhỏ hơn hoặc bằng năm hiện tại
            if (!int.TryParse(txtNamXuatBan.Text.Trim(), out int namXB) || namXB <= 0 || namXB > DateTime.Now.Year)
            {
                MessageBox.Show($"Năm xuất bản phải là định dạng số nguyên dương và không được lớn hơn năm hiện tại ({DateTime.Now.Year})!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            // Kiểm tra đơn giá bán phải lớn hơn hoặc bằng 0
            if (!decimal.TryParse(txtDonGia.Text.Trim(), out decimal donGia) || donGia < 0)
            {
                MessageBox.Show("Đơn giá bán của sách phải là số và phải có giá trị lớn hơn hoặc bằng 0!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        // Chức năng THÊM mới thông tin sách
        private async void btnThem_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateFields(isCheckDuplicateId: true)) return;

            try
            {
                var newBook = new Book
                {
                    MaSach = txtMaSach.Text.Trim(),
                    TenSach = txtTenSach.Text.Trim(),
                    TacGia = txtTacGia.Text.Trim(),
                    NamXuatBan = int.Parse(txtNamXuatBan.Text.Trim()),
                    DonGia = decimal.Parse(txtDonGia.Text.Trim())
                };

                db.Books.Add(newBook);
                await db.SaveChangesAsync(); // Lưu dữ liệu bất đồng bộ

                await LoadDataAsync();
                ClearForm();
                MessageBox.Show("Thêm mới cuốn sách vào thư viện thành công!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gặp lỗi trong quá trình lưu dữ liệu: " + ex.Message, "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Chức năng SỬA thông tin sách hiện hành
        private async void btnSua_Click(object sender, RoutedEventArgs e)
        {
            if (dgDanhSachSach.SelectedItem is Book selectedBook)
            {
                if (!ValidateFields(isCheckDuplicateId: false)) return;

                try
                {
                    var editBook = await db.Books.FindAsync(selectedBook.MaSach);
                    if (editBook != null)
                    {
                        editBook.TenSach = txtTenSach.Text.Trim();
                        editBook.TacGia = txtTacGia.Text.Trim();
                        editBook.NamXuatBan = int.Parse(txtNamXuatBan.Text.Trim());
                        editBook.DonGia = decimal.Parse(txtDonGia.Text.Trim());

                        await db.SaveChangesAsync();
                        await LoadDataAsync();
                        ClearForm();
                        MessageBox.Show("Cập nhật thay đổi thông tin sách thành công!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Gặp lỗi trong quá trình cập nhật dữ liệu: " + ex.Message, "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng click chuột vào bảng để chọn cuốn sách cần sửa đổi thông tin!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Chức năng XÓA sách được chọn khỏi hệ thống
        private async void btnXoa_Click(object sender, RoutedEventArgs e)
        {
            if (dgDanhSachSach.SelectedItem is Book selectedBook)
            {
                var confirmResult = MessageBox.Show($"Bạn có chắc chắn muốn xóa cuốn sách có mã '{selectedBook.MaSach}' ra khỏi danh sách không?",
                                                    "Xác nhận xóa dữ liệu", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (confirmResult == MessageBoxResult.Yes)
                {
                    try
                    {
                        var removeBook = await db.Books.FindAsync(selectedBook.MaSach);
                        if (removeBook != null)
                        {
                            db.Books.Remove(removeBook);
                            await db.SaveChangesAsync();

                            await LoadDataAsync();
                            ClearForm();
                            MessageBox.Show("Đã xóa cuốn sách thành công!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Gặp lỗi trong quá trình thực thi lệnh xóa: " + ex.Message, "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Vui lòng click chuột chọn một dòng sách cần xóa dưới danh sách bảng!", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Chức năng LÀM MỚI (Xóa sạch nội dung chữ trong các ô nhập dữ liệu)
        private void btnLamMoi_Click(object sender, RoutedEventArgs e)
        {
            ClearForm();
        }

        // Hàm tiện ích hỗ trợ dọn dẹp form nhập liệu
        private void ClearForm()
        {
            txtMaSach.Clear();
            txtTenSach.Clear();
            txtTacGia.Clear();
            txtNamXuatBan.Clear();
            txtDonGia.Clear();

            txtMaSach.IsEnabled = true; // Mở khóa lại ô nhập mã sách phục vụ thêm mới
            dgDanhSachSach.SelectedItem = null; // Bỏ vùng chọn trên DataGrid
        }
    }
}